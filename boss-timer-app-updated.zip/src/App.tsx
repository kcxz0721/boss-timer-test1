import React, { useEffect, useState } from "react";

interface Boss {
  name: string;
  interval: number;
}

interface LogEntry {
  name: string;
  time: string;
}

const App: React.FC = () => {
  const [bosses, setBosses] = useState<Boss[]>(() => {
    const saved = localStorage.getItem("bosses");
    return saved ? JSON.parse(saved) : [];
  });
  const [name, setName] = useState("");
  const [interval, setInterval] = useState("");
  const [log, setLog] = useState<LogEntry[]>(() => {
    const saved = localStorage.getItem("log");
    return saved ? JSON.parse(saved) : [];
  });
  const [editMode, setEditMode] = useState(false);

  useEffect(() => {
    localStorage.setItem("bosses", JSON.stringify(bosses));
  }, [bosses]);

  useEffect(() => {
    localStorage.setItem("log", JSON.stringify(log));
  }, [log]);

  const addBoss = () => {
    if (!name || !interval) return;
    setBosses([...bosses, { name, interval: parseInt(interval) }]);
    setName("");
    setInterval("");
  };

  const handleBossClick = (boss: Boss) => {
    if (editMode) return;
    const now = new Date();
    const respawn = new Date(now.getTime() + boss.interval * 60 * 60 * 1000);
    const newLog = [{ name: boss.name, time: respawn.toISOString() }, ...log];
    setLog(newLog);
    scheduleNotification(boss.name, boss.interval);
  };

  const deleteBoss = (name: string) => {
    const updated = bosses.filter((b) => b.name !== name);
    setBosses(updated);
  };

  const scheduleNotification = async (name: string, interval: number) => {
    if (!("Notification" in window)) return;
    if (Notification.permission !== "granted") {
      await Notification.requestPermission();
    }
    if (Notification.permission === "granted") {
      const notifyTime = interval * 60 * 60 * 1000;
      setTimeout(() => {
        new Notification(`${name} BOSS 即將重生！`);
      }, notifyTime - 5 * 60 * 1000);
    }
  };

  const getCountdown = (time: string) => {
    const now = new Date();
    const target = new Date(time);
    const diff = target.getTime() - now.getTime();
    if (diff <= 0) return "已重生";
    const hrs = Math.floor(diff / (1000 * 60 * 60));
    const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const secs = Math.floor((diff % (1000 * 60)) / 1000);
    return `${hrs.toString().padStart(2, "0")}:${mins
      .toString()
      .padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div style={{ padding: "1rem", maxWidth: "600px", margin: "auto" }}>
      <h1 style={{ fontSize: "20px", fontWeight: "bold", textAlign: "center" }}>
        天堂M BOSS 時間表
      </h1>

      <div
        style={{
          backgroundColor: "#f0f0f0",
          padding: "0.5rem",
          borderRadius: "10px",
          marginTop: "1rem",
          fontSize: "14px",
        }}
      >
        <h2 style={{ fontSize: "16px" }}>新增 BOSS</h2>
        <input
          placeholder="BOSS 名稱"
          value={name}
          onChange={(e) => setName(e.target.value)}
          style={{ padding: "0.3rem", marginRight: "0.3rem", fontSize: "14px" }}
        />
        <input
          placeholder="間隔（小時）"
          type="number"
          value={interval}
          onChange={(e) => setInterval(e.target.value)}
          style={{ padding: "0.3rem", width: "60px", marginRight: "0.3rem", fontSize: "14px" }}
        />
        <button
          onClick={addBoss}
          style={{
            padding: "0.3rem 0.5rem",
            backgroundColor: "#007bff",
            color: "white",
            fontSize: "14px",
          }}
        >
          新增
        </button>
      </div>

      <div style={{ marginTop: "1rem", position: "relative" }}>
        <button
          onClick={() => setEditMode(!editMode)}
          style={{
            position: "absolute",
            right: 0,
            top: 0,
            fontSize: "14px",
            backgroundColor: "#999",
            color: "white",
            padding: "0.2rem 0.5rem",
            borderRadius: "5px",
          }}
        >
          {editMode ? "完成" : "編輯"}
        </button>

        <h2 style={{ fontSize: "16px" }}>BOSS 管理</h2>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap: "0.5rem",
            marginTop: "0.5rem",
          }}
        >
          {bosses.map((boss, index) => (
            <div key={index} style={{ position: "relative" }}>
              <button
                onClick={() => handleBossClick(boss)}
                style={{
                  width: "100%",
                  padding: "0.3rem",
                  fontSize: "13px",
                  backgroundColor: "#28a745",
                  color: "white",
                  borderRadius: "5px",
                }}
              >
                {boss.name}
              </button>
              {editMode && (
                <button
                  onClick={() => deleteBoss(boss.name)}
                  style={{
                    position: "absolute",
                    top: "-5px",
                    right: "-5px",
                    backgroundColor: "red",
                    color: "white",
                    borderRadius: "50%",
                    width: "18px",
                    height: "18px",
                    fontSize: "12px",
                    lineHeight: "18px",
                    textAlign: "center",
                    padding: 0,
                  }}
                >
                  ×
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      <div style={{ marginTop: "1rem" }}>
        <h2 style={{ fontSize: "16px" }}>預計重生時間（含倒數）</h2>
        <ul style={{ fontSize: "14px" }}>
          {log.map((entry, index) => (
            <li key={index}>
              {entry.name} ➤{" "}
              {new Date(entry.time).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })}
              <span style={{ marginLeft: "10px", color: "gray" }}>
                （{getCountdown(entry.time)}）
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default App;
