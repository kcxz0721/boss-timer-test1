import React from "react";
import ReactDOM from "react-dom/client";

const App = () => <h1>天堂M BOSS Timer Q版</h1>;

ReactDOM.createRoot(document.getElementById("root")!).render(<App />);
